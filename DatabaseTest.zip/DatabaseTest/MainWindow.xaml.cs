﻿using System.Windows;
using System.Windows.Controls;

namespace DatabaseTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static Frame Frame { get; set; }

        // string connnectionstring = "SERVER=localhost;DATABASE=mydatabase;UID=root;PASSWORD=toor;";

        public MainWindow()
        {
            InitializeComponent();
            Frame = frami;
            frami.Content = new ViewPage();
        }
    }
}
