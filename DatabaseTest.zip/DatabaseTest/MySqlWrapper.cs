﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace DatabaseTest
{
    public class MySqlWrapper
    {
        public string ConnectionString { get; } 

        public MySqlWrapper(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public List<object> GetObjectListWithCommand(string sqlCommand)
        {
            var Reader = ExecuteOnDatabase(sqlCommand);
            var rowList = GetRows(Reader);
            return  BuildObjectListFromRowList(rowList);
        }

        public List<object> BuildObjectListFromRowList(List<List<object>> rowList)
        {
            List<object> objectList = new List<object>();

            foreach (var temp in rowList)
            {
                objectList.Add(new
                {
                    Name = temp[0],
                });
            }

            return objectList;
        }

        public List<List<object>> GetRows(MySqlDataReader Reader)
        {
            List<List<object>> rowList = new List<List<object>>();

            int listIndex = 0;

            while (Reader.Read())
            {
                rowList.Add(new List<object>());

                for (int i = 0; i < Reader.FieldCount; i++)
                {
                    rowList[listIndex].Add(Reader.GetValue(i).ToString());
                }

                listIndex++;
            }

            return rowList;
        }

        public MySqlDataReader ExecuteOnDatabase(string sqlCommand)
        {
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = sqlCommand;
            connection.Open();

            return command.ExecuteReader();
        }
    }
}
