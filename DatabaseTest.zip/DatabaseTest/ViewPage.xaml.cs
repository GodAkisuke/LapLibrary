﻿using System.Windows;
using System.Windows.Controls;

namespace DatabaseTest
{
    /// <summary>
    /// Interaction logic for ViewPage.xaml
    /// </summary>
    public partial class ViewPage : Page
    {
        public ViewPage()
        {
            InitializeComponent();
            GetDatabaseData();
        }

        public void GetDatabaseData()
        {
            string connnectionstring = "SERVER=localhost;DATABASE=berufsschule;UID=root;PASSWORD=toor;";

            MySqlWrapper wrapper = new MySqlWrapper(connnectionstring);

            string sqlCommand = "select * from schuler;";

            ListiViewi.ItemsSource = wrapper.GetObjectListWithCommand(sqlCommand);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Frame.Content = new AddPage();
        }
    }
}
