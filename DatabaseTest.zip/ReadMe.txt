Bedienoberfläche
--------------------
Sprache: C#
Framework: WPF / .net Core 3.1


Datenbank:
--------------
MySql 8.0
